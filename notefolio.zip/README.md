- UI 구조 잡기 (HTML 레이아웃 구조 잡기)
- Tailwind CSS 스타일링 익숙해지기 (flex, grid 차이점 이해 등)
- 변하지 않는(혹은 쉽게 변하지 않는) 데이터의 경우 Constants 폴더에서 관리하기
- Shadcn UI에서 설치한 Basic 컴포넌트 관리하기 (경로 최소화 - index.js 파일에서 한 번에 관리하기)
- Custom 컴포넌트의 경우에도 위와 동일하게 관리하기

- 메인 헤더 Sticky 적용하기 및 Sticky Menu도 함께 적용하기
