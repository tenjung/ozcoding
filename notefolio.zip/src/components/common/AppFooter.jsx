import React from "react";

function AppFooter() {
  return <div>AppFooter</div>;
}

export { AppFooter };
