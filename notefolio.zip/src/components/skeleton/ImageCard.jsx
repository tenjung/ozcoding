import { AvatarImage } from "../ui";
import { Avatar } from "../ui";
import { AvatarFallback } from "../ui";
import { Skeleton } from "../ui";
import { Eye, Heart } from "lucide-react";
const ContentList = [
  {
    id: 1,
    author: "Max Leiter",
    avatar: "https://github.com/maxleiter.png",
    fallback: "ML",
    views: 1234,
    likes: 123,
  },
  {
    id: 2,
    author: "Evil Rabbit",
    avatar: "https://github.com/evilrabbit.png",
    fallback: "ER",
    views: 5678,
    likes: 456,
  },
  {
    id: 3,
    author: "Shadcn",
    avatar: "https://github.com/shadcn.png",
    fallback: "SH",
    views: 9012,
    likes: 789,
  },
  {
    id: 4,
    author: "Vercel",
    avatar: "https://github.com/vercel.png",
    fallback: "VC",
    views: 3456,
    likes: 234,
  },
  {
    id: 5,
    author: "React",
    avatar: "https://github.com/reactjs.png",
    fallback: "RT",
    views: 7890,
    likes: 567,
  },
  {
    id: 1,
    author: "Max Leiter",
    avatar: "https://github.com/maxleiter.png",
    fallback: "ML",
    views: 1234,
    likes: 123,
  },
  {
    id: 2,
    author: "Evil Rabbit",
    avatar: "https://github.com/evilrabbit.png",
    fallback: "ER",
    views: 5678,
    likes: 456,
  },
  {
    id: 3,
    author: "Shadcn",
    avatar: "https://github.com/shadcn.png",
    fallback: "SH",
    views: 9012,
    likes: 789,
  },
  {
    id: 4,
    author: "Vercel",
    avatar: "https://github.com/vercel.png",
    fallback: "VC",
    views: 3456,
    likes: 234,
  },
  {
    id: 5,
    author: "React",
    avatar: "https://github.com/reactjs.png",
    fallback: "RT",
    views: 7890,
    likes: 567,
  },
];
function SkeletonImageCard() {
  return (
    <section className="flex flex-wrap items-center justify-center gap-6 mt-6 pb-10">
      {ContentList.map((item) => (
        <div key={item.id} className="w-[300px]">
          {/* 메인 이미지 */}
          <Skeleton className="w-full h-70 rounded-lg cursor-pointer" />

          {/* 하단 정보 영역 */}
          <div className="mt-3 flex items-center justify-between">
            {/* 아바타/작성자 정보 */}

            <div className="flex items-center gap-2">
              <Avatar className="w-8 h-8">
                <AvatarImage src={item.avatar} alt={item.author} />
                <AvatarFallback>{item.fallback}</AvatarFallback>
              </Avatar>
              <p className="text-sm font-medium">{item.author}</p>
            </div>

            {/* 조회수/좋아요 */}
            <div className="flex items-center gap-4 text-sm text-gray-600">
              {/* 조회수 */}
              <div className="flex items-center gap-1">
                <Eye size={16} />
                <span>{item.views}</span>
              </div>
              {/* 좋아요 */}
              <div className="flex items-center gap-1">
                <Heart size={16} />
                <span>{item.likes}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </section>
  );
}

export { SkeletonImageCard };
